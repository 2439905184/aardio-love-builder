local num=0
function love.load()
	--love.graphics.print("hello",300,300)
   --love.graphics.setBackgroundColor(255,255,120)
end

function love.draw()
    --love.graphics.print("helloWorld",300,300)
    love.graphics.print(tostring(num),300,300)
end

function love.update(dt)
   if love.keyboard.isDown("up") then
	  
      num = num + 100 * dt -- this would increment num by 100 per second
	  --love.graphics.print("20",400,300)
   end
end
function love.quit()
  print("Thanks for playing! Come back soon!")
end
